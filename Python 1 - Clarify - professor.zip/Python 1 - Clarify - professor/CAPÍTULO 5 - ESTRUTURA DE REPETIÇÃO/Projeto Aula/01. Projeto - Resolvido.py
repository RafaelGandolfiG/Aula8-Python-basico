'''
Enunciado ( leia atentamente cada passo a passo )
================================================

# 1o passo - Declaração das Variáveis
# ===================================
seguindo as boas práticas da programação(convenção),
zere a memória das variáveis para impedir que nela exista um valor 
indevido

    quantidade = recebe o valor zero
         total = recebe o valor zero
         preco = recebe o valor zero
      desconto = recebe o valor zero

# 2o passo - Entrada de Dados
# é o que você deseja que apareça no terminal no formato de pergunta ?
# ====================================================================
    seu script deve solicitar ao usuário a quantidade de itens que serão comprados.

    use o input() para receber somente números:
    exemplo: quantidade = numérico(entrada(Quantos itens quer registrar na compra?))

# 3o passo - Use o FOR
# ====================
    For é utilizado para iterar sobre a quantidade de itens e 
    somar o preço de cada item ao total.

    for suavariavel in range(variavelquantidade):
        variavelpreco recebe monetario(entrada('Digite o preço do item {suavariavel+1}'))
        variaveltotal faz a soma do preco (acumula total dos itens)


# 4o passo - Identificar o tipo de cliente
# ========================================
    
    print(Qual é o tiplo de Cliente ?)
    print(1. Regular (3% de desconto))
    print(2. VIP (12% de desconto))
    print(3. Premium (21% de desconto))

    sua_variavel_tipocliente recebe no formato numérico o número 
    digitado no terminal, exemplo:

    sua_variavel_tipocliente = numérico(entrada('Escolha o tipo de cliente (1-3): '))
    
# 5o passo - Nesta fase use de match:
# ==================================
    match é utilizado para aplicar o desconto de acordo com o tipo de 
    cliente informado pelo usuário.

    match suavariavel:
        caso 1:
            sua_variavel_desconto = 3% de desconto para cliente Regular        
        case 2:
            sua_variavel_desconto = 12% de desconto para cliente VIP         
        case 3:
            sua_variavel_desconto = 21% de desconto para cliente Premium        
        case _:
            entrada(?)

# 6o passo - Calcular o valor total com desconto
===============================================
    
    total_com_desconto = variaveltotal * (1 - variaveldesconto)            


# 7o passo - Exibir os Resultados:
================================

    seu código deve exibir o total de compras, 
    o desconto aplicado e o total com o desconto após calcular

    entrada(Total sem desconto: R$ {??:.2f})
    entrada(Desconto aplicado: R$ {?? * ??:.2f})
    entrada(Total com desconto: R$ {??:.2f})

'''

# Atenção:  os passos descritos acima servem para auxiliar
#           no seu processo de aprendizagem, por isso leia-os atentamente !

# Escreva seu código abaixo:

# 1o passo - Declaração das Variáveis 
# zerar a memória das variaveis inicialmente
# ==========================================
quantidade = 0
total = 0   
preco = 0
desconto = 0

# 2o passo - Entrada de Dados
# ===========================
# 12
quantidade = int(input('Quantos itens deseja registrar na compra: '))


# 3o passo - Use o FOR
# ====================
# Coleta de preços dos itens e cálculo do total
for item in range(quantidade):
    
    preco = float(input(f'Digite o preço do item: {item + 1}: ')) # 4000
    
    # 4000
    # total = total + preco
    total += preco # acumular o total dos itens

# 15000

# 4o passo - Identificar o tipo de cliente
# ========================================
print('\nTipos de Clientes: ')
print('1. Regular 3% de desconto')
print('2. Vip 12% de desconto')
print('3. Premium 21% de desconto')

try: # tentar / validar / garantir que tudo dê certo
   
    tipo_cliente = int(input('Digite o tipo de cliente [1, 2 ou 3]: '))

except Exception as DescricaoDoErro: # em caso de erro mostre a mensagem abaixo
    print('Digite somente números entre: 1, 2 ou 3 para as opções do cliente!')
    print('O programa será encerrado...')
    print(f'A descrição do Erro é: {DescricaoDoErro}')
    exit() # encerra o programa aqui 
    
# 5o passo - Nesta fase use de match:
# ==================================
# Aplica o desconto com base no tipo de cliente usando match
match tipo_cliente:
    case 1:
        desconto = 0.03 # 3% de desconto para Cliente Regular
    case 2:
        desconto = 0.12 # 12% de desconto para Cliente VIP
    case 3:
        desconto = 0.21 # 21% de desconto para Cliente Premium
    case _: # caso contrário
        print('Tipo de cliente inválido! Nenhum desconto será aplicado.')


# 6o passo - Calcular o valor total com desconto
# =============================================
total_com_desconto = total *  (1 - desconto) 

# 7o passo - Exibir os Resultados:
# ===============================
print(f'\nTotal sem desconto: R$ {total:.2f}')
print(f'Valor do Desconto Aplicado: R$ {round(total * desconto,2)}')
print(f'Total com Desconto: R$ {total_com_desconto:.2f}')


