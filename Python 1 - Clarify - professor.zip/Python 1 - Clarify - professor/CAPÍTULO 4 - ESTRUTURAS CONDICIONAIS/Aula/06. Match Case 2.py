"""
    Estrutura condicionais mais utilizada em menus,
    funciona semelhante ao escolha Caso do portugol
    e switch case no java por exemplo...
"""
# Calculadora

# Escreva seu código aqui
menu = int(input('''
[1] SOMAR
[2] SUBTRAIR
[3] MULTIPLICAR
[4] DIVIDIR                 
Digite uma opção:       
                 '''))

if menu >= 1 and menu <=4:
    n1 = int(input('Primeiro número: '))
    n2 = int(input('Segundo número: '))
else:
    print('Opção inválida...')
    print('O programa será encerrado...')
    exit() # encerrar o programa aqui

# Escolha Caso Menu
match menu:
    case 1: # SOMA (+)
        print(f'Somar os valores: {n1 + n2}')
        
    case 2: # SUBTRAIR(-)
        if n1 >= n2:
            print(f'Subtrair os valores, temos: {n1 - n2}')
        else:
            print(f'Subtrair os valores, temos: {n2 - n1}')
            
    case 3: # MULTIPLICAR (*)
        print(f'Mulplicar os valores, temos: {n1 * n2}')
        
    case 4: # DIVIDIR ( / )
        print(f'Didivir os valores, temos: {n1 / n2}')






















