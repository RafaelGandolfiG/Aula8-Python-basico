

# 1o passo - crie um código para exibir uma mensagem
# de boas vindas 
print('Olá Mundo!')
print("Olá Mundo")

# 2o passo - crie uma variável do tipo texto que permita
# receber um nome
nome = input('Digite seu nome: ')

# 3o passo - forma errada de exibir o conteúdo da variável
print('Olá Mundo {nome} ! Prazer em conhecer... ERRADO!')

# 4o passo - modo correto para unir texto com variável
'''
{} = chaves irá receber o conteúdo da variável de 
     entrada( input() )
.format = é o método para receber o contéudo da variável
'''
print('Olá {} ! Prazer em conhecer'.format(nome))

print(f'Olá {nome} ! Prazer em conher (mais utilizado!)')

# 5o passo - valor float (monetários)
'''
.2f = tudo que vier após o ponto considere com 2 casas decimais
f = format
f = format será usado quando desejamos juntar/unir variáveis com texto
ou texto com números/valores
'''
# 25.12
print(f'Preço {25.12345:.2f} float(valor monetário)')

# outra maneira de arredondar
print(f'Preço R$ {round(38.78945,2)} função round()')

# valor inteiro
print(f'O valor inteiro é: {8.9:.0f} zero casas decimais')
print(f'{8.9:.0f}')

# valor formatado em porcentagem
print(f'O valor formatado em porcentagem é: {10.12345:.2f}%')

