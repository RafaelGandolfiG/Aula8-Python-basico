'''
Pede-se:
===========


   VARIAVEIS
   =========
      cod_produto = (numérico) 
      descricao = (texto) 
      preco = (valor decimal)
      ativo = (TRUE)
   
   ENTRADA
   =======
      cod_produto = faça a variável receber somente números
                  ('Digite o código: ') 

      descricao = faça a variável receber somente texto 
                  ('Digite o nome: ') 

      preco = faça a variável receber somente valor decimal
               ('Digite o preço: ')

      produto ativo = faça a variável receber somente boleano(TRUE) verdadeiro


   SAÍDA
   =====
   1) exibir os valores digitados em cada variável (print)
   2) se a variavel produto_ativo for igual TRUE então, 
         exibir 'Produto ativo'
      senão 
         exibir 'Produto inativo'
    
'''

# Bibliotecas do Python:
# https://docs.python.org/3/library/index.html
# https://docs.python.org/3/library/stdtypes.html#str.format

# Conforme todo material que você executou com o professor
# até aqui, chegou sua vez colocar em prática todo conhecimento.

# Leia atentamente o enunciado acima e aplique a solução !
# Boa sorte !
'Escreva seu código abaixo'
# 1o passo - Entradas - variaveis

# cod_produto: recebe número inteiro (apenas números)
cod_produto = int(input('Digite o código: '))

# descricao: recebe texto
descricao = input('Digite o nome: ')

# preco: recebe valor decimal (float)
preco = float(input('Digite o preço: '))

# ativo: recebe valor booleano True
produto_ativo = True

# 2o passo - exibir os conteúdos das variáveis acima
print('\nDados do produto:')
print(f'Código do produto: {cod_produto}')
print(f'Descrição: {descricao}')
print(f'Preço: {preco:.2f}')

# se o conteúdo da variável for igual a True, então 
# mostre a mensagem
if produto_ativo == True:
   print('Produto ativo')
else: # senão
   print('Produto inativo')








