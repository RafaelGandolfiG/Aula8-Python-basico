'''
    LISTAS: 
        Adição 
        Remoção 
        Alteração de valores
        Ordenação

        
        * APPENDD >>> Atribui a lista, um elemento por vez. 
        * INSERT >>> Atribui vários elementos, integrando à lista original.
        * POP >>> Remove um valor da lista por índice.
        * REMOVE >>> Remove um valor da lista por valor.
        * SORT >>> Ordena os dados de uma lista.
        

'''

produtos = ['monitor', 
            'notebook',
            'teclado',
            'mouse']

print('Estoque inicial:')
print(produtos)

produtos.append('impressora') 
print(f'Produto impressora adicionado(.append): {produtos}')

produtos.insert(2, 'headset') 
print(f'Produto headset inserido(.insert): {produtos}')

produtos.remove('mouse') 
print(f'Produto mouse retirado(.remove): {produtos}')

removido = produtos.pop(1) 
print(f'Produto removido(.pop): {removido}')
print(f'Estoque após a remoção: {produtos}')

produtos[0] = 'monitor led' 

produtos[-1] = 'impressora a laser'

print(f'Após alteração: {produtos}')

produtos.sort() 
print('Produtos em ordem alfabética [A-Z]')
print(produtos)

produtos.sort(reverse=True) 
print('Produtos em ordem reversa: [Z-A]')
print(produtos)














































































