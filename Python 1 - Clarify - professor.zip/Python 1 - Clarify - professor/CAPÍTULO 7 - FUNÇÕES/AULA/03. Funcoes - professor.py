'''

Cálculo de Comissão de Vendas
=============================

O sistema de comissão de vendas de uma empresa 
precisa calcular o valor a ser pago a um vendedor, 
com base no valor das vendas realizadas. 

A comissão do vendedor varia de acordo com a faixa de 
valor das vendas, conforme as regras abaixo:

Regras de Comissão:
===================

    Não atingiu a meta:
    ------------------- 
    - se o valor vendido menor ou igual a R$ 4.000,00, 
      a comissão será de 1% sobre o valor vendido.


    Atingiu a meta: 
    ---------------
    - se o valor vendido for maior do que R$ 4.000,00 e 
      menor ou igual a R$ 8.000,00 a comissão será de 
      5% sobre o valor vendido.

    Superou a meta: 
    ---------------
    - se o valor vendido for superior a R$ 8.000,00
      a comissão será de 10% sobre o valor vendido.


PEDE-SE
=======

1) O programa deve solicitar: 
    - nome do vendedor
    - valor total vendido

2) O valor da venda será informado no 
    formato brasileiro, com separador de milhar (ex: 1.500,00).

3) O sistema deve calcular a comissão do 
    vendedor com base nas faixas de vendas e 
    determinar o valor final a ser pago (valor vendido + comissão).

4) O valor final a ser pago deve ser exibido no 
    formato de moeda brasileira (ex: R$ 1.500,00).

5) exibir:
    nome do vendedor
    comissão aplicada
    valor das vendas
    valor total a ser pago ao vendedor      

'''
# seu código aqui

# 2o passo - Função
def Calcular_Total_A_Pagar(receber_comissao, receber_valor_vendido):
    return receber_valor_vendido + (receber_valor_vendido * receber_comissao)

# 3o passo - Função
def Formatar_Moeda(valor):
    texto = f'R$ {valor:_.2f}'
    return texto.replace('.',',').replace('_','.')


###### 1o passo #### Início do programa
nome_vendedor = input('Nome do vendedor: ').upper()
valor_vendido = float(input('Valor total vendido: '))

if valor_vendido <= 4000:
    comissao = 0.01 # 1%
# senão se
elif valor_vendido > 4000 and valor_vendido <= 8000:
    comissao = 0.05 # 5%
else: # senão
    comissao = 0.10 # 10%

# calcular o valor total a receber considerando 
# o valor_vendido e comissao
valor_a_pagar = Calcular_Total_A_Pagar(comissao, valor_vendido)

# exibir os resultados com os valores formatados
print(f'Vendedor: {nome_vendedor}')
print(f'Comissão aplicada: {int(comissao * 100)}%')
print(f'Valor vendido: {Formatar_Moeda(valor_vendido)}')
print(f'Valor a receber: {Formatar_Moeda(valor_a_pagar)}')










































































