'''
CENÁRIO
=======

Cálculo de Impostos com Desconto e Entrada de Produtos
------------------------------------------------------

Uma empresa deseja automatizar o processo de cálculo de 
impostos sobre produtos vendidos, considerando também 
eventuais descontos aplicados ao consumidor.

Pede-se crie um programa para:
-----------------------------

1) Solicite ao usuário quantos produtos deseja cadastrar.

2) Para cada produto, o usuário deve informar:

    Nome do produto

    Preço original (antes do desconto)

    Valor do desconto aplicado ao produto


3) O programa deve calcular:

    a) O valor dos impostos (IR, ISS, CSLL) com base no preço original

    b) IR (Imposto de Renda):

            20% para produtos com preço até R$ 2.000,00

            30% para produtos com preço acima de R$ 2.000,00

    c) ISS: 15% do preço original

    d) CSLL: 5% do preço original

    e) O preço final com desconto

4) Para cada produto, exibir:

    Nome do produto

    Preço original (formatado como moeda brasileira)

    Valor do desconto

    Preço final com desconto

    Valor total dos impostos calculados

'''
# seu código aqui

# 2o passo - Função 
# sempre que criar uma função coloque no início do programa
# caso contrário a função não será executada
# def = definir / criar
def calcular_imposto_total(recebe_valor):  # 15000  
    # calculo do IR
    if recebe_valor <= 2000:
        imposto_ir = 0.2 * recebe_valor # 20%
    else:
        imposto_ir = 0.3 * recebe_valor # 30%
    
    imposto_iss = iss * recebe_valor
    imposto_csll = csll * recebe_valor
    
    imposto_final = imposto_ir + imposto_iss + imposto_csll

    # obrigatoriamente coloque o return, para devolver o resultado
    # desta função para o programa que chamou
    return imposto_final
    

# 3o passo - Função - para formatar o valor no padrão brasileiro
# 5000.00
def Formatar_Moeda(valor):
    
    # usar '_' para facilitar a separação de milhar
    # 5_000.00
    texto = f'R$ {valor:_.2f}'

    # converter para vírgula decimal e 
    # ponto para milhar
    # 5.000,00
    return texto.replace('.', ',').replace('_','.')


############# 1o passo - Início do Programa ##############
iss = 0.15 # 15%
csll = 0.05 # 5%

# Looping(FOR) que repete o processo para cada produto informado
quantidade_produtos = int(input('Quantos produtos deseja cadastrar: '))

for numero_produto in range(quantidade_produtos): # 5
    
    print(f'Produto: {numero_produto + 1}')
    
    # coletar o nome do produto
    nome_produto = input('Digite o nome do produto: ') # ar-condicionado
    
    preco = float(input('Digite o preço do produto: ')) # 15000
    
    desconto = float(input('Digite o valor do desconto: '))/100 # 0.05
    
    # cálculos
    # 1890.77
    imposto_total = calcular_imposto_total(preco)    # 15000
    preco_com_desconto = preco - (desconto * preco)
    
    # formatações de Moeda - Brasil
    texto_preco = Formatar_Moeda(preco) # 15.000,00
    texto_preco_com_desconto = Formatar_Moeda(preco_com_desconto)
    texto_imposto_tot = Formatar_Moeda(imposto_total)
    
    # exibir resultados
    print(f'\nResultado do produto: {nome_produto}')
    print(f'Preço original: {texto_preco}')
    print(f'Desconto aplicado: {int(desconto * 100)}%')
    print(f'Preço com desconto: {texto_preco_com_desconto}')
    print(f'Imposto total sobre preço original: {texto_imposto_tot}')
    






























































