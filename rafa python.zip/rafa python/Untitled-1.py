from datetime import date
import getpass

def main():
    while True:
        data_atual = date.today().strftime('%d/%m/%Y')
        print('-'*50)
        print(f'{data_atual}\n')
        print('Olá usuário!! Seja bem-vindo')
        print('-'*50)
        try:
            escolha = int(input('1-Logar\n2-Criar conta\n3-Sair\nEscolha: '))
            print('-'*50)
            if escolha == 1:
                login()
            elif escolha == 2:
                criar()
            elif escolha == 3:
                print('Saindo... Até logo!')
                break
            else:
                print('Opção inválida')
        except ValueError:
            print('Digite um número válido!')
        print()

def login():
    global email
    email = (input('Digite seu email: ').lower().strip())
    senha = getpass.getpass('Digite sua senha: ').strip()

    try:
        with open('usuarios.txt', 'r') as usuarios:
            for linha in usuarios:
                email_salvo, senha_salva = linha.strip().split(',')
                if email == email_salvo and senha == senha_salva:
                    print('-'*50)
                    print('Login realizado com sucesso!')
                    return home(email)
        print('-'*50)
        print('Email ou senha incorretos!')
    except FileNotFoundError:
        print('Nenhuma conta encontrada. Crie uma conta primeiro!')

def criar():
    global email
    email = input('Digite seu email: ').lower().strip()
    senha = getpass.getpass('Digite sua senha: ').strip()

    # Verifica se já existe
    try:
        with open('usuarios.txt', 'r') as usuarios:
            for linha in usuarios:
                email_salvo, _ = linha.strip().split(',')
                if email == email_salvo:
                    print('-'*50)
                    print('Este email já está cadastrado!')
                    return
    except FileNotFoundError:
        pass  # Se o arquivo não existir, será criado depois

    # Cria nova conta
    with open('usuarios.txt', 'a') as usuarios:
        usuarios.write(f'{email},{senha}\n')

    print('-'*50)
    print('Conta criada com sucesso!!')

def home():
    nome = email.split('@')[0]
    print('-'*50)
    print(f'Bem-vindo ao menu principal, {nome}!')
    print('-'*50)
    input('Pressione ENTER para voltar ao menu...')

if __name__ == "__main__":
    main()
